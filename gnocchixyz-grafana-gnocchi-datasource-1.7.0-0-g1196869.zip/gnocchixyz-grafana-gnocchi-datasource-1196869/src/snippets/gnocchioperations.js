ace.define("ace/snippets/gnocchioperation",["require","exports","module"], function(require, exports, module) {
"use strict";

// exports.snippetText = "# rate\n\
// snippet r\n\
//   rate(${1:metric}[${2:range}])\n\
// ";

exports.snippets = [];
//  {
//    "content": "host = 'foobar'",
//    "name": "host",
//    "scope": "gnocchioperation",
//    "tabTrigger": "h"
//  }
//];

exports.scope = "gnocchioperation";
});

