export default class TemplateSrvMock {
    replace(value: string, format: any){
        return value;
    }
}
